OK_FORMAT = True

test = {   'name': 'q_1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> assert type(fahrenheit) == float\n',
                                       'failure_message': 'deberias devolver tu respuesta como un float',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Buen Trabajo'},
                                   {   'code': '>>> assert celsius == 36.0\n>>> \n>>> \n>>> \n',
                                       'failure_message': 'hay algo mal en tu formula de conversion de grados revisala',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Buen Trabajo'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}

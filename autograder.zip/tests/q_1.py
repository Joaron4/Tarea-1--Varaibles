OK_FORMAT = True

test = {   'name': 'q_1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> type(fahrenheit) == float\nTrue',
                                       'failure_message': 'deber�as devolver tu respuesta como un float',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '�Buen Trabajo!'},
                                   {   'code': '>>> celsius == 36.0\n>>> \n>>> \n>>> \nTrue',
                                       'failure_message': 'hay algo mal en tu formula de conversi�n de grados rev�sala',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '�Buen Trabajo!'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
